using Microsoft.Ajax.Utilities;

namespace UEFARankingV2.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using UEFARankingV2.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<UEFARankingV2.Models.UEFARankingV2Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(UEFARankingV2.Models.UEFARankingV2Context context)
        {
            context.Teams.AddOrUpdate(p => p.Name,
                new Team
                {
                    Name = "Lincoln Red Imps",
                    League = "Gibraltar League",
                    Nation = "Gibraltar",
                    CoEfficient = 0.000,
                    RoundToEnter = "One"
                },

                new Team
                {
                    Name = "Levadia Tallinn",
                    League = "Estonian League",
                    Nation = "Estonia",
                    CoEfficient = 1.111,
                    RoundToEnter = "One"
                },
                new Team
                {
                    Name = "La Fiorita",
                    League = "San Marino League",
                    Nation = "San Marino",
                    CoEfficient = 0.567,
                    RoundToEnter = "One"
                },
                new Team
                {
                    Name = "HB Torshavn",
                    League = "Faroe Islands League",
                    Nation = "Faroe Islands",
                    CoEfficient = 0.432,
                    RoundToEnter = "One"
                },
                new Team
                {
                    Name = "Banants",
                    League = "Armenia League",
                    Nation = "Armenia",
                    CoEfficient = 1.321,
                    RoundToEnter = "One"
                },

                new Team
                {
                    Name = "FC Santa Coloma",
                    League = "Andorra League",
                    Nation = "Andorra",
                    CoEfficient = 1.688,
                    RoundToEnter = "One"
                }
                );
        }
    }
}
